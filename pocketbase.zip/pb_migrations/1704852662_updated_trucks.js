/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("x980rbtodzcnpxf")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "gy1qinud",
    "name": "plate",
    "type": "text",
    "required": true,
    "presentable": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("x980rbtodzcnpxf")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "gy1qinud",
    "name": "plate",
    "type": "text",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
})
