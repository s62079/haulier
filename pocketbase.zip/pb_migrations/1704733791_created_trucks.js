/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const collection = new Collection({
    "id": "x980rbtodzcnpxf",
    "created": "2024-01-08 17:09:51.356Z",
    "updated": "2024-01-08 17:09:51.356Z",
    "name": "trucks",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "gy1qinud",
        "name": "plate",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "indexes": [],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("x980rbtodzcnpxf");

  return dao.deleteCollection(collection);
})
