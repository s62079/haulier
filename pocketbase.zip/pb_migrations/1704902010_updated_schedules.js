/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // remove
  collection.schema.removeField("qskehm4l")

  // remove
  collection.schema.removeField("udkzdqpd")

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "qskehm4l",
    "name": "posStart",
    "type": "text",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "udkzdqpd",
    "name": "posEnd",
    "type": "text",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
})
