/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // remove
  collection.schema.removeField("aojjxo30")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ddo58ntk",
    "name": "status",
    "type": "select",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "scheduled",
        "done",
        "cancelled"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "aojjxo30",
    "name": "geoPaths",
    "type": "json",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSize": 2000000
    }
  }))

  // remove
  collection.schema.removeField("ddo58ntk")

  return dao.saveCollection(collection)
})
