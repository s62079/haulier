/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ddo58ntk",
    "name": "status",
    "type": "select",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "scheduled",
        "started",
        "finished",
        "cancelled"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("279e7g3xkyi5vvd")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "ddo58ntk",
    "name": "status",
    "type": "select",
    "required": true,
    "presentable": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "scheduled",
        "done",
        "cancelled"
      ]
    }
  }))

  return dao.saveCollection(collection)
})
